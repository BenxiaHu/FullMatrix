from .FullMatrix import main
main()