# Full Matrix package
**Full Matrix** can be used to make a full matrix for each chromosome.
FullMatrix -i *chrsize* -r *resolution* -o *output*
**-i**: chromosome size
**-r**: the window size spliting each chromosome
**-o**: the name of output file

## Installation
python>=3.6

pip install FullMatrix